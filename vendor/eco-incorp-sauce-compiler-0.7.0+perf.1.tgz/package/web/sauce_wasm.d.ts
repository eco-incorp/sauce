/* tslint:disable */
/* eslint-disable */

/** The engine a program is compiled for. */
export type SauceTarget = "evm" | "svm";

/**
 * Fetch a module's bytes. A Node `Buffer` is a `Uint8Array`.
 *
 * Returning `undefined`/`null` means **nothing at this path**, which is the signal the per-target
 * arm probe relies on to fall back to a module's neutral arm (`token.ts` after `token.evm.ts`
 * misses). A **throw** means the path names something that could not be read: it propagates rather
 * than falling back, so a miss must not throw. Any other return type is a resolve error.
 *
 * A `.json` path is asked for either as a contract ABI or as a document the source imports as data
 * (`with { type: "json" }`); both are bytes here, so serve any `.json` the program names.
 */
export type ResolveModule = (path: string) => Uint8Array | undefined | null;

/**
 * Map a bare specifier (`"@sauce/token"`) to a path `resolve` accepts. `undefined`/`null` declines,
 * falling back to using the specifier as a path; a throw means the package is not installed.
 * `importer` is the resolved path of the importing module.
 */
export type ResolvePackage = (
specifier: string,
importer: string,
) => string | undefined | null;

export interface CompileOptions {
    /** Required. */
    target: SauceTarget;
    /** Required. */
    resolve: ResolveModule;
    resolvePackage?: ResolvePackage;
    /** The entry module the resolver is asked for first. Defaults to `"main.js"`. */
    entry?: string;
    /**
     * `[name, path]` pairs declaring contracts the host holds by path. Each `path` resolves as a
     * **bare** `import Name from "./path.json"` would, and emits the same bytes — so a program whose
     * ABI is a file the resolver already serves can say so in its own source instead. The same
     * specifier under `with { type: "json" }` reads the file as data rather than as an ABI.
     */
    contracts?: Array<[name: string, path: string]>;
    /**
     * `[name, abi]` pairs declaring contracts whose ABI JSON is given directly, rather than a path
     * `resolve` must fetch — for a caller that already holds an ABI in memory (a synthesized ABI
     * map, a value read from somewhere other than the filesystem) and would otherwise have to
     * teach its resolver about a synthetic path just to hand back a string it already has. Applied
     * to the entry module only, exactly like `contracts`; a name colliding with a `contracts`
     * entry, an inline `import`, another `inlineContracts` entry, or a declared function is a
     * compile error either way.
     */
    inlineContracts?: Array<[name: string, abi: string]>;
    /**
     * Module specifiers whose exports are broadcast into every module: an ambient module's
     * exported functions and consts become callable/readable with no `import` line. Each specifier
     * resolves exactly like a bare/relative `import` (through `resolve`/`resolvePackage`); an
     * ambient module defining `main` is a compile error (an ambient module is a library, never the
     * entry).
     *
     * Precedence: ambient always loses to user code — a name the module declares, imports, or
     * binds as a contract, a JSON data import or a named type wins silently, and a function-local
     * or parameter
     * shadows an ambient const for free.
     *
     * A module has **one namespace**, so an occupied name blocks the broadcast on *both* channels: a
     * declared `const f` leaves no ambient `function f` to call, and a declared `function f` no
     * ambient `const f` to read. Two different ambient modules exporting the same name is a compile
     * error.
     *
     * Each specifier passes the same guards a written `import` of it would: an absolute path, a
     * per-target arm (`./token.evm.js`), a subpath, or a `.json` file is refused either way — a
     * broadcast root is SauceScript, which neither reading of a `.json` is.
     */
    ambient?: Array<string>;
    /**
     * Compile-time parameters, as `[name, value]` pairs. Each is injected into **every** module as a
     * module-scope `const`, so a `const`-gated branch (`if (FLAG) { … }`) is decided at compile time
     * and the arm that cannot run is dropped.
     *
     * A value is a decimal or `0x`-hex integer string, with an optional trailing `n` and `_`
     * separators — the same literal syntax the source uses. It is a string rather than a `number`
     * because a define is a 256-bit word, which JS `number` cannot carry.
     *
     * Precedence is the *opposite* of `ambient`: a define **overrides** the module's own `const` of
     * that name, on both channels, so an `import` of it reads the defined value too. A define is a
     * build parameter, not a competing name — the source's declaration is what it stands in for when
     * the build supplies none. It does not override a module-scope `let`, a declared function, a
     * lookup table, a bound contract, a JSON data import's binding, or an import's local alias — each
     * is a compile error naming the define — and a function-local or parameter shadows it lexically.
     * A name imported under its own name is left to its import, which already carries the defined
     * value; a data import is refused instead, because a document read from a file has no declaration
     * for the define to stand in for, so applying it nowhere would leave the option a silent no-op.
     * The value must be assignable to the declaration's type (only `0`/`1` reaches a `boolean`), and
     * the name must be one a source file could spell.
     *
     * A repeated name is an error rather than a last-wins override.
     *
     * The name is **program-wide**: "every module" includes packages you did not write, so a
     * dependency's own `const` of that name is replaced with no diagnostic, and one that binds the
     * name to anything else fails the compile with a module path its consumer may never have opened.
     * Pick a name nobody else would choose.
     */
    defines?: Array<[name: string, value: string]>;
    /** Constant folding. Defaults to `true`. */
    optimize?: boolean;
    /** Use compact-v1 arguments. Encode with the returned entrySchema. */
    compactArgs?: boolean;
    /**
     * The **per-function IR-lowering cache**. Defaults to `true` — a JS consumer that sets nothing
     * gets it on. It memoizes each declared function's AST→IR lowering in a process-global store,
     * keyed on the function's source-span text, the target, the resolved global-slot sequence its
     * lowering touches, and a fingerprint of every external binding it consulted (define, imported
     * `const`/JSON table, contract ABI, callee signature); recompiling the same program under a
     * different `defines` sweep — the eco-swap solver's per-route case — reuses every function whose
     * lowering a changed define does not move.
     *
     * Set `false` for a guaranteed-fresh compile. The store persists across `compile()` calls in one
     * WASM instance (a single-threaded instance ⇒ its `thread_local` store is an instance global);
     * call `clearFunctionCache()` to empty it — the analogue of the TS compiler's
     * `clearDefaultCompileCache()`, to run after an imported file's bytes change within the process.
     */
    cache?: boolean;
}

/**
 * What a caller's account must satisfy at a declared slot — the four values of Solana's own
 * `AccountRole`, so an SDK maps one onto an `AccountMeta` directly.
 *
 * It is the program author's **assertion**, with the trust model of an ABI declaration: the compiler
 * cannot know what a program invoked by CPI does with the accounts it is handed, so nothing here is
 * inferred. A bare `Account` is `"readonly"`.
 */
export type AccountRole =
| "readonly"
| "writable"
| "readonly_signer"
| "writable_signer";

/**
 * One entry in the attach contract. A `slot` is an `Account` parameter of `main`, read by the engine
 * at `index`, carrying the source parameter's `name` and the role it `requires` of whatever account
 * is attached there — every account the compiler knows at compile time is one of these, including an
 * `svm.call` callee, which is an ordinary declared account named by the slot it occupies.
 *
 * `remaining` is not an account but a **position**: it marks where the caller's own variable-length
 * accounts begin, and `from` is the index the first of them lands at. It appears only when the program
 * reads that tail (`svm.remainingAccount` / `svm.remainingAccounts`), and it is always last, because
 * the tail's length is the caller's choice and nothing positional can follow it. It carries no role:
 * how many accounts follow, and what each is for, is the caller's own choice.
 */
export type AccountEntry =
| { kind: "slot"; index: number; name: string; requires: AccountRole }
| { kind: "remaining"; from: number };

/** The index-to-account contract a caller attaches accounts against. SVM only. */
export interface AccountManifest {
    accounts: AccountEntry[];
}

export interface CompileResult {
    bytecode: Uint8Array;
    isaRevision: "stack-compact-v1";
    entryEncoding: "abi-v1" | "compact-v1";
    entrySchema?: Uint8Array;
    /** The SVM account manifest. `undefined` on the EVM, which has no such concept. */
    manifest?: AccountManifest;
}

/** The per-function IR-lowering cache's counters, from `functionCacheStats()`. */
export interface FnCacheStats {
    hits: number;
    misses: number;
    inserts: number;
}



/**
 * Empty the per-function IR-lowering cache — the analogue of the TS compiler's
 * `clearDefaultCompileCache()`.
 *
 * The store is a process-global `thread_local` that persists across [`compile`] calls in one WASM
 * instance: a `wasm32-unknown-unknown` instance is single-threaded, so its one thread's
 * `thread_local` *is* an instance-wide global, and that is why the cache warms across routes with
 * no explicit handle to pass around. That same persistence is why a host must be able to drop it:
 * the cache key fingerprints module-binding *values*, but not a change to what a resolver returns
 * for the same path mid-process (an edited imported file), so a host that mutates its inputs
 * between compiles clears the cache to force a fresh lowering — exactly as the TS surface does.
 */
export function clearFunctionCache(): void;

/**
 * Compile a SauceScript program to Sauce bytecode.
 *
 * The option and result shapes are the TypeScript declarations above — `CompileOptions` and
 * `CompileResult` — and they are the single description of them. This comment deliberately does not
 * restate the per-option detail: it used to, and the generated `.d.ts` then carried the same
 * sentences twice, in the type docs and in this rustdoc, with nothing keeping them in step.
 *
 * What only this comment can say is the failure mode. A compile or resolve failure **throws a JS
 * `Error`** carrying the same rustc-style diagnostic the CLI prints — never a WASM trap, and never a
 * swallowed cause: a host callback that throws has its own message threaded into the chain. That is
 * the boundary's contract and no type expresses it.
 */
export function compile(options: CompileOptions): CompileResult;

/**
 * Read the per-function IR-lowering cache's counters — `{ hits, misses, inserts }` — for measuring
 * warm-reuse across a route sweep. Counters are cumulative until [`clear_function_cache`] resets
 * them (clearing the store zeroes the counters too).
 */
export function functionCacheStats(): FnCacheStats;

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
    readonly memory: WebAssembly.Memory;
    readonly clearFunctionCache: () => void;
    readonly compile: (a: any) => [number, number, number];
    readonly functionCacheStats: () => [number, number, number];
    readonly __wbindgen_malloc: (a: number, b: number) => number;
    readonly __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
    readonly __wbindgen_exn_store: (a: number) => void;
    readonly __externref_table_alloc: () => number;
    readonly __wbindgen_externrefs: WebAssembly.Table;
    readonly __externref_table_dealloc: (a: number) => void;
    readonly __wbindgen_start: () => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;

/**
 * Instantiates the given `module`, which can either be bytes or
 * a precompiled `WebAssembly.Module`.
 *
 * @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
 *
 * @returns {InitOutput}
 */
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
 * If `module_or_path` is {RequestInfo} or {URL}, makes a request and
 * for everything else, calls `WebAssembly.instantiate` directly.
 *
 * @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
 *
 * @returns {Promise<InitOutput>}
 */
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;
