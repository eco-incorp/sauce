# @eco-incorp/sauce-compiler

The SauceScript compiler, compiled to WebAssembly. A thin `wasm-bindgen` marshalling layer over the
Rust compiler core, with no compiler logic of its own. The core is I/O-free, so the JS host supplies a
synchronous resolver — in Node, backed by `fs`.

Compiles to both targets — **EVM** and **SVM** (Solana) — and runs in both environments, Node and
the browser. One package ships both builds; see [JS API](#js-api).

## Documentation

**[sauce.eco.com](https://sauce.eco.com)** — the language reference, the builtins reference, and the
guides. This page documents the **JS API** of this package and nothing else: what SauceScript itself
can express lives there.

> **Installable by anyone; not open source.** Licensed under the **Eco Proprietary License 1.0**,
> which ships in the package as `LICENSE.md`. Publishing to the public registry means there is no
> token to configure — it grants no use rights beyond that license. The source repository is private.

> **Versioning is semver**, and which bump a breaking change gets depends on the version you are on.
> On **`1.x` and later**, a breaking change to the JS API (the shape of `CompileOptions`,
> `CompileResult`, or the resolver contract) is a **major** bump, new options and exports are minor,
> and fixes are patch. On a **`0.x`** version the API is not stable — semver says anything may change
> — and this package's rule there is that a breaking change is a **minor** bump, so pin exactly.
> Either way, a change to what SauceScript *compiles to* is a compiler change rather than an API
> change: read the release notes for bytecode, not the version.

## Install

```sh
npm install @eco-incorp/sauce-compiler
```

Compiling one file, in Node, in full:

```js
const { readFileSync } = require("node:fs");
const { join } = require("node:path");
const { compile } = require("@eco-incorp/sauce-compiler");

const root = "./src";
const { bytecode } = compile({
  entry: "main.ts",
  target: "evm",
  // `path` is the specifier as the source wrote it, so join it against a root.
  resolve: (path) => {
    try {
      return readFileSync(join(root, path));
    } catch {
      return undefined; // nothing at this path — see `resolve` under Options
    }
  },
});
```

## JS API

The package ships **two builds of the same wasm** and picks between them by `exports` condition, so
the import is the same either way — what differs is whether you have to initialize it.

**Node** (`require`, or `import` from ESM) resolves to the CommonJS build, which loads the wasm off
disk itself. Nothing to await:

```js
const { compile } = require("@eco-incorp/sauce-compiler");
```

**Browsers and bundlers** resolve to the ESM build, whose default export initializes the wasm. Call
it once before the first `compile`:

```js
import init, { compile } from "@eco-incorp/sauce-compiler";

await init(); // fetches the wasm next to the module; or pass bytes/a URL explicitly
```

**Either environment**, if you would rather not care which one you are in — `ready()` initializes
where that is needed and is a no-op where it is not:

```js
import { ready } from "@eco-incorp/sauce-compiler/ready";

const { compile } = await ready();
```

Prefer this in code that runs in both, such as an app that compiles in the browser and in its Node
tests. It saves branching on which build you got: TypeScript resolves only one `exports` condition,
so the alternative is describing the other build's shape by hand and casting into it. Call it as often
as you like — initialization happens once, and concurrent callers share the one attempt.

The package ships its **own TypeScript types** — `CompileOptions`, `CompileResult`,
`AccountManifest`, `AccountEntry`, `AccountRole`, `SauceTarget`, `ResolveModule`, `ResolvePackage`,
`FnCacheStats` — so a consumer does not declare them. That is deliberate: an entry point typed
`(options: any) => any` pushes every consumer into hand-writing the option and result shapes to get
checking back, and two consumers then hold two copies of one contract that drift. Import the types
from here instead:

```ts
import init, { compile, type CompileOptions } from "@eco-incorp/sauce-compiler";
```

Either way `compile` is the same function:

```js

const { bytecode, manifest } = compile({
  entry: "main.ts", // optional, default "main.js"
  target: "evm", // "evm" | "svm"
  resolve(path) {
    // required: return the module's bytes as a Uint8Array (a Node Buffer is one).
    // `path` arrives AS THE SOURCE SPELLED IT — `"./token.json"` keeps its `./`, and
    // nothing is normalized for you. Join it against a root, or strip the `./` before
    // a map lookup; a map keyed by bare filename silently answers "absent".
    // Return undefined when there is nothing at `path` — that is how the per-target
    // arm probe (`token.evm.ts` before `token.ts`) learns an arm does not exist.
    // Throw only when the path names something you could not read: a throw is a hard
    // failure and will NOT fall back to the neutral arm.
    if (!existsSync(join(root, path))) return undefined;
    return fs.readFileSync(join(root, path));
  },
  resolvePackage(specifier, importer) {
    // optional: map a bare specifier ("@sauce/token") to a path resolve() accepts.
    // Return undefined to decline — the specifier is then used as a path unchanged.
    // Throw if the package is genuinely not installed.
    return mapPackage(specifier, importer);
  },
  contracts: [["ERC20", "./out/ERC20.json"]], // optional: [name, path] ABI pairs
  inlineContracts: [["Token", tokenAbiJson]], // optional: [name, abi] pairs, ABI JSON inline
  ambient: ["@sauce/token"], // optional: modules broadcast into every module, no import line
  defines: [["FEE_BPS", "30"]], // optional: [name, value] compile-time consts, value as a string
  optimize: true, // optional, default true
  cache: true, // optional, default true — see Caching
});
// bytecode: Uint8Array
// manifest: object on the SVM target (the account manifest), undefined on the EVM
```

### Options

| Option           | Type                              | Notes                                                                                                                                 |
| ---------------- | --------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------- |
| `target`         | `"evm" \| "svm"`                  | Required.                                                                                                                             |
| `resolve`        | `(path) => Uint8Array \| undefined` | Required. `path` is the specifier **as written** — a relative import keeps its `./`, and nothing is normalized — so join it against a root rather than keying a map by bare filename. `undefined`/`null` means "nothing at this path". Anything else is a resolve error, never silently-empty source. A `.json` path may be either a contract ABI or a document the source imports as data (`with { type: "json" }`) — both are bytes here, so serve any `.json` the program names. |
| `resolvePackage` | `(specifier, importer) => string \| undefined` | Optional. `undefined`/`null` declines, and the specifier is then used as a path unchanged.                                  |
| `entry`          | `string`                          | Optional, default `"main.js"`.                                                                                                        |
| `contracts`      | `[name, path][]`                  | Optional. Contracts the host declares by path; each `path` is passed to `resolve`. Emits the same bytes as a **bare** `import Name from "./path.json"` in the source, which is the spelling to prefer when the ABI is a file the resolver already serves; the same specifier under `with { type: "json" }` reads the file as data instead. |
| `inlineContracts` | `[name, abi][]`                  | Optional. Contracts whose ABI JSON is given directly rather than a path `resolve` must fetch, for a caller that already holds an ABI in memory. Entry module only, exactly like `contracts`; a name colliding with either is a compile error. |
| `ambient`        | `string[]`                        | Optional. Module specifiers broadcast into every module — their exports are callable/readable with no `import` line. Each resolves as an `import` of it would. Ambient always loses to user code: a name the module declares, imports, or binds as a contract, a JSON data import or a named type wins silently. A module has one namespace, so an occupied name blocks the broadcast whether the two are both functions, both bindings, or one of each. |
| `defines`        | `[name, value][]`                 | Optional. Compile-time parameters injected into every module as module-scope `const`s. Each `value` is a decimal or `0x`-hex integer **string** (a define is a 256-bit word, which JS `number` cannot carry), with an optional trailing `n` and `_` separators. Precedence is the opposite of `ambient`: a define **overrides** the module's own `const` of that name, on both channels, so an `import` of it reads the defined value too. It does not override a module-scope `let`, a declared function, a lookup table, a bound contract, a JSON data import's binding, or an import's local alias — each is a compile error naming the define — and a function-local or parameter shadows it. A name imported under its own name is left to its import, which already carries the defined value; a data import is refused instead, because a document read from a file has no declaration for the define to stand in for and applying it nowhere would leave the option a silent no-op. The value must be assignable to the declaration's type (only `0`/`1` reaches a `boolean`) and the name must be one a source file could spell. A repeated name is an error, not a last-wins override. **The name is program-wide** — "every module" includes packages the host did not write, so a dependency's own `const` of that name is replaced with no diagnostic, and one that binds the name to anything else fails the compile; pick a name nobody else would choose. |
| `optimize`       | `boolean`                         | Optional, default `true`. Constant folding + propagation.                                                                             |
| `cache`          | `boolean`                         | Optional, default `true`. The per-function IR-lowering cache — see [Caching](#caching). Set `false` for a guaranteed-fresh compile.    |

### How a `.json` import is read

A **bare** `import Name from "./x.json"` binds a **contract ABI**. The same specifier under
`with { type: "json" }` reads the file as **data** instead. Both arrive at `resolve` as bytes, so a
resolver serves any `.json` the program names and does not need to tell the two apart.

`with { type: "json" }` is the only attribute accepted: an unknown key or value, an empty
`with {}`, more than one attribute, an `assert { … }` clause, and the attribute on a `.js`/`.ts`
specifier are each a compile error naming what was wrong. A config file imported *without* the
attribute reports that it is valid JSON but not a contract ABI, rather than a missing `abi` field.

## Caching

`compile` memoizes function lowerings, on by default. The key is a function's source text, the
target, and a fingerprint of every external binding its lowering read — so recompiling one program
under many `defines` reuses the functions a changed define does not move. That is the workload it
exists for; a single compile pays a little and gains nothing.

The store lives in the **WASM instance**, so it persists across `compile()` calls and is emptied
only by `clearFunctionCache()`:

```js
const { compile, clearFunctionCache, functionCacheStats } = require("@eco-incorp/sauce-compiler");

compile(options);
functionCacheStats(); // { hits, misses, inserts } — this instance's counters, not the process's

// Call this when a module's BYTES change within one process — a file edited on disk between
// compiles. The key is the source text the resolver returned, so a changed file that the resolver
// re-reads keys differently on its own; what needs clearing is a resolver of your own that caches.
clearFunctionCache();
```

Correctness does not depend on clearing: a changed source changes the key. `cache: false` is there
for when you would rather not reason about that at all.

## Errors

A resolve or compile failure throws a JS `Error` — never a WASM trap. Its `message` is the full
rustc-style diagnostic: the rule that was broken, the source line, and a caret under the span. A host
callback that throws is not swallowed either; its own message is threaded into the chain, so a
resolver that failed says so rather than surfacing as a generic compile error.

