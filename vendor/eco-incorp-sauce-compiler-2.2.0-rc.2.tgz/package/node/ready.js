// The `node` half of `@eco-incorp/sauce-compiler/ready`.
//
// The CommonJS glue reads the wasm off disk and instantiates it during `require`, so by the time
// this module has loaded there is nothing to wait for. `ready()` is still async, because its whole
// purpose is to be the *same call* in every environment — a consumer that awaited here and not in
// the browser would be back to branching on the environment.
//
// `source` is accepted and ignored: on this target the bytes are always the sibling file. Taking the
// argument keeps the signature identical to the web shim, so the shared `ready.d.ts` describes both.
const compiler = require("./sauce_wasm.js");

async function ready(_source) {
  return compiler;
}

module.exports = { ready };
