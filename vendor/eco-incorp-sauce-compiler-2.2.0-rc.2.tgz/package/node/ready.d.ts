import type { CompileOptions, CompileResult } from "./sauce_wasm.js";

/**
 * What `compile` needs before it can run, where that differs by environment.
 *
 * Omit it and the browser build resolves the wasm next to its own module, which is what a bundler
 * rewrites to an asset URL. Pass bytes or a URL when that does not apply. The Node build ignores it —
 * the bytes are always the sibling file — and accepts it only so both environments have one
 * signature.
 *
 * Deliberately spelled without DOM types. One declaration file serves both builds, so a `Response`
 * or a `BufferSource` here would make the **Node** build fail to typecheck for a consumer whose `lib`
 * is `["ES2022"]` with no DOM — and those errors surface from inside `node_modules`, which is the
 * worst place to debug them. A `Response` still works at run time in a browser; it is simply not in
 * the shared type. Widen it locally if you need one:
 * `ready(response as unknown as WasmSource)`.
 *
 * `{ href: string }` is how a `URL` is accepted without naming the DOM type: `href` is what a `URL`
 * actually has, so a real one satisfies it structurally. Spelled `{ url: string }` it would reject
 * every `URL` — they have no `url` property — while accepting a `{ url }` object the initializer
 * cannot use. Wrong in both directions at once.
 */
export type WasmSource =
  | ArrayBuffer
  | ArrayBufferView
  | { href: string }
  | string;

/** The compiler, once it is ready to use. */
export interface SauceCompiler {
  compile(options: CompileOptions): CompileResult;
}

/**
 * Get the compiler, initialising the wasm if this environment needs it.
 *
 * The same call in Node and in the browser: the CommonJS build is already initialised by the time it
 * resolves, and the browser build is initialised by it. Safe to call as often as you like —
 * initialisation happens at most once, concurrent callers share the one attempt, and a failed attempt
 * is not cached, so a retry is a real retry. The first *successful* `source` is the one used; a later
 * one is ignored, because wasm initialisation is global to the module.
 *
 * **Types** resolve under any `moduleResolution`, including the legacy `node`: the package maps this
 * subpath through `typesVersions` as well as `exports`. That is only safe because both builds share
 * one declaration file — there is no "wrong" one to point at — so it says nothing about which build
 * loads at run time.
 *
 * **At run time** this subpath needs `node16`, `nodenext` or `bundler`: it is declared through
 * `exports`, which legacy `node` resolution and pre-5 bundlers do not read. The package root
 * (`@eco-incorp/sauce-compiler`) works everywhere, since it also has top-level `main`/`browser`.
 *
 * ```ts
 * import { ready } from "@eco-incorp/sauce-compiler/ready";
 *
 * const { compile } = await ready();
 * const { bytecode } = compile({ target: "evm", resolve: (path) => sources[path] });
 * ```
 */
export declare function ready(source?: WasmSource): Promise<SauceCompiler>;
