// The `browser` half of `@eco-incorp/sauce-compiler/ready`.
//
// The ESM glue cannot read from disk, so it exports an initializer that fetches the wasm and must be
// awaited before `compile` works. `ready()` does that once and hands back the module.
//
// **Only success is sticky.** The obvious `initialized ??= init(...)` is wrong: `??=` assigns only
// when the slot is nullish, and a *rejected* promise is not nullish — so one failed fetch of the
// 1.7 MB wasm (offline, a 404, a CDN hiccup) would be cached and replayed to every later caller for
// the lifetime of the page, with no way to retry. Clearing the slot on rejection is what makes the
// "call it as often as you like" contract true.
//
// `source` is optional and forwarded. With nothing passed, the generated initializer resolves the
// wasm as `new URL("sauce_wasm_bg.wasm", import.meta.url)`, which is what a bundler rewrites to an
// asset URL. Pass bytes, a `Response`, or a URL where that does not apply — a test reading the file
// itself, or a host that serves the asset from somewhere the bundler cannot see.
//
// **The first successful `source` wins, and a later different one warns.** wasm initialisation is
// global to the module, so once it has succeeded there is nothing to redo — but silently ignoring a
// second `source` is how a stale or wrong wasm build stays in use with nothing to notice. The
// comparison is identity only: establishing that two `ArrayBuffer`s are equivalent is not cheap, and
// a caller who read the same file twice would earn a spurious complaint. So a warning rather than a
// throw, and only for a genuinely different object. A *failed* attempt is not remembered, so a retry
// with different bytes does take effect.
import init, * as compiler from "./sauce_wasm.js";

let initialized;
let initializedFrom;

export async function ready(source) {
  if (initialized === undefined) {
    initializedFrom = source;
    initialized = init(
      source === undefined ? undefined : { module_or_path: source },
    ).catch((error) => {
      initialized = undefined;
      initializedFrom = undefined;
      throw error;
    });
  } else if (source !== undefined && source !== initializedFrom) {
    console.warn(
      "@eco-incorp/sauce-compiler: ready() is already initialised, so this `source` is ignored and " +
        "the module keeps the wasm it loaded first. Pass `source` on the first call, or not at all.",
    );
  }

  await initialized;

  return compiler;
}
